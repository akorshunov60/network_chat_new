package Practice_4.HomeWork;

public interface AuthService {

    String getUsernameByLoginAndPassword(String login, String password);
}
